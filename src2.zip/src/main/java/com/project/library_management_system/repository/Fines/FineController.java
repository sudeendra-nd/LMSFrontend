package com.project.library_management_system.contollers;

import com.project.library_management_system.services.FineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/fines")
public class FineController {

    @Autowired
    private FineService finesService;


    @GetMapping("/myFines")
    public ResponseEntity<Map<String, Object>> getUserFines() {
        return finesService.getUserFines();
    }


    @PostMapping("/pay/{fineId}")
    public ResponseEntity<Map<String, Object>> payFine(@PathVariable Long fineId) {
        return finesService.payFine(fineId);
    }


    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllFines() {
        return finesService.getAllFines();
    }


    @PostMapping("/markPaid/{fineId}")
    public ResponseEntity<Map<String, Object>> markFineAsPaid(@PathVariable Long fineId) {
        return finesService.markFineAsPaid(fineId);
    }
}
