package com.project.library_management_system.repository;

import com.project.library_management_system.entity.FineEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FineRepository extends JpaRepository<FineEntity, Long> {
    List<FineEntity> findByUserId(Long userId);
}
