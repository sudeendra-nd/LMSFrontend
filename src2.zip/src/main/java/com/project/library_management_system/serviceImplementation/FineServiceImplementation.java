package com.project.library_management_system.serviceImplementation;

import com.project.library_management_system.entity.FineEntity;
import com.project.library_management_system.entity.LendingEntity;
import com.project.library_management_system.entity.userEntity;
import com.project.library_management_system.repository.FineRepository;
import com.project.library_management_system.repository.LendingRepository;
import com.project.library_management_system.repository.userRepository;
import com.project.library_management_system.services.FineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.*;

@Service
public class FineServiceImplementation implements FineService {

    @Autowired
    private FineRepository fineRepository;

    @Autowired
    private LendingRepository lendingRepository;

    @Autowired
    private userRepository userRepository;

    @Override
    public ResponseEntity<Map<String, Object>> getUserFines() {
        Map<String, Object> response = new HashMap<>();

        // Fetch logged-in username
        String username = SecurityContextHolder.getContext().getAuthentication().getName();

        // Get userEntity by username
        Optional<userEntity> optionalUser = userRepository.findByUsername(username);
        if (!optionalUser.isPresent()) {
            response.put("message", "User not found!");
            return ResponseEntity.badRequest().body(response);
        }

        userEntity currentUser = optionalUser.get();

        // Fetch all lending records for the user
        List<LendingEntity> lendings = lendingRepository.findByUser_Id(currentUser.getId());
        List<Map<String, Object>> finesList = new ArrayList<>();

        LocalDate today = LocalDate.now();

        for (LendingEntity lending : lendings) {
            if (lending.getDueDate() != null && lending.getReturnDate() == null) {
                // Convert java.util.Date to java.time.LocalDate
                Date dueDate = lending.getDueDate();
                LocalDate dueDateLocal = dueDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

                long daysLate = ChronoUnit.DAYS.between(dueDateLocal, today);

                if (daysLate > 0) {
                    double fineAmount = daysLate * 10.0; // ₹10 fine per day

                    Map<String, Object> fineDetails = new HashMap<>();
                    fineDetails.put("lendingId", lending.getId());
                    fineDetails.put("bookTitle", lending.getBook().getTitle());
                    fineDetails.put("dueDate", dueDateLocal); // sending LocalDate
                    fineDetails.put("daysLate", daysLate);
                    fineDetails.put("fineAmount", fineAmount);
                    finesList.add(fineDetails);
                }
            }
        }

        response.put("fines", finesList);
        return ResponseEntity.ok(response);
    }

    @Override
    public ResponseEntity<Map<String, Object>> payFine(Long fineId) {
        Map<String, Object> response = new HashMap<>();

        Optional<FineEntity> fineOpt = fineRepository.findById(fineId);
        if (fineOpt.isPresent()) {
            FineEntity fine = fineOpt.get();
            fine.setPaid(true);
            fineRepository.save(fine);
            response.put("message", "Fine paid successfully!");
        } else {
            response.put("message", "Fine not found!");
        }
        return ResponseEntity.ok(response);
    }

    @Override
    public ResponseEntity<Map<String, Object>> getAllFines() {
        Map<String, Object> response = new HashMap<>();
        List<FineEntity> allFines = fineRepository.findAll();
        response.put("allFines", allFines);
        return ResponseEntity.ok(response);
    }

    @Override
    public ResponseEntity<Map<String, Object>> markFineAsPaid(Long fineId) {
        Map<String, Object> response = new HashMap<>();

        Optional<FineEntity> fineOpt = fineRepository.findById(fineId);
        if (fineOpt.isPresent()) {
            FineEntity fine = fineOpt.get();
            fine.setPaid(true);
            fineRepository.save(fine);
            response.put("message", "Fine marked as paid.");
        } else {
            response.put("message", "Fine not found!");
        }
        return ResponseEntity.ok(response);
    }
}
