package com.project.library_management_system.dto;

import lombok.Data;

@Data
public class LoginDTO {
    private String username;
    private String password;
}
