package com.project.library_management_system.services;

import org.springframework.http.ResponseEntity;
import java.util.Map;

public interface FineService {

    ResponseEntity<Map<String, Object>> getUserFines();

    ResponseEntity<Map<String, Object>> payFine(Long fineId);

    ResponseEntity<Map<String, Object>> getAllFines();

    ResponseEntity<Map<String, Object>> markFineAsPaid(Long fineId);
}
