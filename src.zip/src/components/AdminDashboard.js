import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button, Container, Table, Form, Row, Col, Badge, Spinner } from 'react-bootstrap';
import Layout from './Layout';
import axiosInstance from '../axiosInstance';
import { FaSearch, FaTimes, FaPlus, FaEdit, FaTrash, FaBook, FaUserCog } from 'react-icons/fa';
import { toast } from 'react-toastify';

const AdminDashboard = () => {
    const [books, setBooks] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredBooks, setFilteredBooks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [deletingBooks, setDeletingBooks] = useState({});

    useEffect(() => {
        fetchBooks();
    }, []);

    const fetchBooks = async () => {
        try {
            const response = await axiosInstance.get('/api/books');
            const bookData = response.data.content;
            setBooks(bookData);
            setFilteredBooks(bookData);
        } catch (error) {
            console.error('Error fetching books:', error);
            toast.error('Failed to load books. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        const results = books.filter(book =>
            book.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            book.author?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            book.isbn?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            book.copies_available?.toString().toLowerCase().includes(searchTerm.toLowerCase())
        );
        setFilteredBooks(results);
    }, [searchTerm, books]);

    const deleteBook = async (id) => {
        setDeletingBooks(prev => ({ ...prev, [id]: true }));
        try {
            await axiosInstance.delete(`/api/books/${id}`);
            setBooks(books.filter(book => book.id !== id));
            toast.success('Book deleted successfully');
        } catch (error) {
            console.error('Error deleting book:', error);
            toast.error('Failed to delete book. Please try again.');
        } finally {
            setDeletingBooks(prev => ({ ...prev, [id]: false }));
        }
    };

    return (
        <Layout>
            <Container fluid>
                {/* Header Section */}
                <div style={{ 
                    background: 'linear-gradient(135deg, #4b6cb7 0%, #182848 100%)',
                    padding: '25px',
                    borderRadius: '15px',
                    marginBottom: '25px',
                    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
                }}>
                    <div className="d-flex justify-content-between align-items-center">
                        <div>
                            <h1 className="text-white mb-0">Admin Dashboard</h1>
                            <p className="text-white-50 mb-0">Manage your library inventory</p>
                        </div>
                        <div className="d-flex gap-3">
                            <Link 
                                to="/member-management" 
                                className="btn btn-light"
                                style={{
                                    padding: '10px 20px',
                                    borderRadius: '8px',
                                    fontWeight: '600',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px'
                                }}
                            >
                                <FaUserCog /> Manage Members
                            </Link>
                            <Link 
                                to="/add" 
                                className="btn btn-light"
                                style={{
                                    padding: '10px 20px',
                                    borderRadius: '8px',
                                    fontWeight: '600',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px'
                                }}
                            >
                                <FaPlus /> Add New Book
                            </Link>
                        </div>
                    </div>
                </div>

                {/* Search Section */}
                <div style={{ 
                    background: 'white',
                    padding: '20px',
                    borderRadius: '10px',
                    marginBottom: '25px',
                    boxShadow: '0 2px 4px rgba(0,0,0,0.05)'
                }}>
                    <Row className="align-items-center">
                        <Col md={10}>
                            <div className="position-relative">
                                <FaSearch className="position-absolute" style={{ left: '15px', top: '12px', color: '#6c757d' }} />
                                <Form.Control
                                    type="text"
                                    placeholder="Search by title, author, ISBN, or copies available"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    style={{ 
                                        paddingLeft: '40px',
                                        borderRadius: '8px',
                                        border: '1px solid #e0e0e0',
                                        fontSize: '0.95rem',
                                        height: '45px'
                                    }}
                                />
                            </div>
                        </Col>
                        <Col md={2}>
                            <Button 
                                variant="outline-secondary" 
                                onClick={() => setSearchTerm('')}
                                className="w-100"
                                style={{
                                    height: '45px',
                                    borderRadius: '8px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    gap: '8px'
                                }}
                            >
                                <FaTimes /> Clear
                            </Button>
                        </Col>
                    </Row>
                </div>

                {/* Content Section */}
                <div style={{ 
                    background: 'white',
                    padding: '25px',
                    borderRadius: '10px',
                    boxShadow: '0 2px 4px rgba(0,0,0,0.05)'
                }}>
                    {loading ? (
                        <div className="text-center p-5">
                            <Spinner animation="border" variant="primary" />
                            <p className="mt-3 text-muted">Loading books...</p>
                        </div>
                    ) : filteredBooks.length === 0 ? (
                        <div className="text-center p-5">
                            <FaBook style={{ fontSize: '48px', color: '#dee2e6' }} />
                            <h4 className="mt-3">No books found</h4>
                            <p className="text-muted">Try adjusting your search criteria</p>
                        </div>
                    ) : (
                        <div className="table-responsive">
                            <Table hover style={{ marginBottom: 0 }}>
                                <thead>
                                    <tr style={{ background: '#f8f9fa' }}>
                                        <th style={{ padding: '15px', borderTop: 'none' }}>ID</th>
                                        <th style={{ padding: '15px', borderTop: 'none' }}>Title</th>
                                        <th style={{ padding: '15px', borderTop: 'none' }}>Author</th>
                                        <th style={{ padding: '15px', borderTop: 'none' }}>ISBN</th>
                                        <th style={{ padding: '15px', borderTop: 'none' }}>Copies</th>
                                        <th style={{ padding: '15px', borderTop: 'none' }}>Status</th>
                                        <th style={{ padding: '15px', borderTop: 'none' }}>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {filteredBooks.map(book => (
                                        <tr key={book.id}>
                                            <td style={{ padding: '15px', verticalAlign: 'middle' }}>{book.id}</td>
                                            <td style={{ padding: '15px', verticalAlign: 'middle' }}>
                                                <div className="d-flex align-items-center">
                                                    <img 
                                                        src={book.image_url || 'https://via.placeholder.com/40x60?text=No+Image'} 
                                                        alt={book.title}
                                                        style={{ 
                                                            width: '40px', 
                                                            height: '60px', 
                                                            objectFit: 'cover',
                                                            borderRadius: '4px',
                                                            marginRight: '10px'
                                                        }}
                                                        onError={(e) => {
                                                            e.target.src = 'https://via.placeholder.com/40x60?text=No+Image';
                                                        }}
                                                    />
                                                    <span style={{ fontWeight: '500' }}>{book.title}</span>
                                                </div>
                                            </td>
                                            <td style={{ padding: '15px', verticalAlign: 'middle' }}>{book.author}</td>
                                            <td style={{ padding: '15px', verticalAlign: 'middle' }}>
                                                <code style={{ background: '#f8f9fa', padding: '4px 8px', borderRadius: '4px' }}>
                                                    {book.isbn}
                                                </code>
                                            </td>
                                            <td style={{ padding: '15px', verticalAlign: 'middle' }}>{book.copies_available}</td>
                                            <td style={{ padding: '15px', verticalAlign: 'middle' }}>
                                                <Badge bg={book.copies_available > 0 ? 'success' : 'danger'} style={{ padding: '8px 12px' }}>
                                                    {book.copies_available > 0 ? 'In Stock' : 'Out of Stock'}
                                                </Badge>
                                            </td>
                                            <td style={{ padding: '15px', verticalAlign: 'middle' }}>
                                                <div className="d-flex gap-2">
                                                    <Link 
                                                        to={`/editbook/${book.id}`} 
                                                        className="btn btn-sm"
                                                        style={{
                                                            background: 'linear-gradient(135deg, #ffd3a5 0%, #fd6585 100%)',
                                                            border: 'none',
                                                            color: 'white',
                                                            padding: '8px 16px',
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            gap: '6px'
                                                        }}
                                                    >
                                                        <FaEdit /> Edit
                                                    </Link>
                                                    <Button
                                                        variant="danger"
                                                        size="sm"
                                                        onClick={() => deleteBook(book.id)}
                                                        disabled={deletingBooks[book.id]}
                                                        style={{
                                                            background: deletingBooks[book.id] ? '#dc3545' : 'linear-gradient(135deg, #ff9a9e 0%, #ff5252 100%)',
                                                            border: 'none',
                                                            padding: '8px 16px',
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            gap: '6px'
                                                        }}
                                                    >
                                                        {deletingBooks[book.id] ? (
                                                            <>
                                                                <Spinner
                                                                    as="span"
                                                                    animation="border"
                                                                    size="sm"
                                                                    role="status"
                                                                    aria-hidden="true"
                                                                />
                                                                <span className="ms-1">Deleting...</span>
                                                            </>
                                                        ) : (
                                                            <>
                                                                <FaTrash /> Delete
                                                            </>
                                                        )}
                                                    </Button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </Table>
                        </div>
                    )}
                </div>
            </Container>
        </Layout>
    );
};

export default AdminDashboard;