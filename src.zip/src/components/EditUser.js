import React, { useState, useEffect } from 'react';
import { Container, Form, Button, Card } from 'react-bootstrap';
import { useParams, useNavigate } from 'react-router-dom';
import { FaUser, FaSave, FaTimes, FaEnvelope, FaPhone, FaMapMarkerAlt, FaUserShield } from 'react-icons/fa';
import axiosInstance from '../axiosInstance';
import { toast } from 'react-toastify';

const EditUser = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [user, setUser] = useState({
        username: '',
        email: '',
        phone: '',
        address: '',
        role: ''
    });

    useEffect(() => {
        const fetchUser = async () => {
            try {
                const response = await axiosInstance.get('/api/users');
                const users = response.data;
                const targetUser = users.find(u => u.id === parseInt(id));
                if (targetUser) {
                    setUser(targetUser);
                } else {
                    toast.error('User not found');
                    navigate('/member-management');
                }
            } catch (error) {
                console.error('Error fetching user:', error);
                toast.error('Failed to load user details');
                navigate('/member-management');
            } finally {
                setLoading(false);
            }
        };

        fetchUser();
    }, [id, navigate]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUser(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSaving(true);
        try {
            // Prepare the update data
            const updateData = {
                ...user,
                // Only include password if it's been changed
                password: user.password || undefined
            };
            
            const response = await axiosInstance.put(`/api/users/${id}`, updateData);
            if (response.data.status === 'success') {
                toast.success('User updated successfully');
                navigate('/member-management');
            } else {
                toast.error(response.data.message || 'Failed to update user');
            }
        } catch (error) {
            console.error('Error updating user:', error);
            toast.error(error.response?.data?.message || 'Failed to update user');
        } finally {
            setSaving(false);
        }
    };

    return (
        <Container className="py-5">
            <Card className="border-0" style={{
                background: 'linear-gradient(145deg, #ffffff 0%, #f5f7fa 100%)',
                borderRadius: '20px',
                boxShadow: '0 10px 20px rgba(0,0,0,0.08)'
            }}>
                <Card.Header style={{
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                    borderRadius: '20px 20px 0 0',
                    padding: '25px'
                }}>
                    <div className="d-flex align-items-center">
                        <div className="bg-white p-2 rounded-circle me-3">
                            <FaUser className="text-primary" size={24} />
                        </div>
                        <div>
                            <h4 className="mb-0 text-white">Edit User Profile</h4>
                            <p className="mb-0 text-white-50">Update user information</p>
                        </div>
                    </div>
                </Card.Header>
                <Card.Body className="p-4">
                    {loading ? (
                        <div className="text-center p-5">
                            <div className="spinner-border text-primary" role="status">
                                <span className="visually-hidden">Loading...</span>
                            </div>
                            <p className="mt-3 text-muted">Loading user details...</p>
                        </div>
                    ) : (
                        <Form onSubmit={handleSubmit}>
                            <div className="row">
                                <div className="col-md-6">
                                    <Form.Group className="mb-4">
                                        <div className="d-flex align-items-center mb-2">
                                            <FaUser className="text-primary me-2" />
                                            <Form.Label className="mb-0">Username</Form.Label>
                                        </div>
                                        <Form.Control
                                            type="text"
                                            name="username"
                                            value={user.username}
                                            onChange={handleChange}
                                            disabled
                                            style={{
                                                background: '#f8f9fa',
                                                border: '2px solid #e9ecef',
                                                borderRadius: '10px',
                                                padding: '12px'
                                            }}
                                        />
                                    </Form.Group>
                                </div>
                                <div className="col-md-6">
                                    <Form.Group className="mb-4">
                                        <div className="d-flex align-items-center mb-2">
                                            <FaEnvelope className="text-primary me-2" />
                                            <Form.Label className="mb-0">Email</Form.Label>
                                        </div>
                                        <Form.Control
                                            type="email"
                                            name="email"
                                            value={user.email}
                                            onChange={handleChange}
                                            required
                                            style={{
                                                border: '2px solid #e9ecef',
                                                borderRadius: '10px',
                                                padding: '12px'
                                            }}
                                        />
                                    </Form.Group>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-md-6">
                                    <Form.Group className="mb-4">
                                        <div className="d-flex align-items-center mb-2">
                                            <FaPhone className="text-primary me-2" />
                                            <Form.Label className="mb-0">Phone</Form.Label>
                                        </div>
                                        <Form.Control
                                            type="text"
                                            name="phone"
                                            value={user.phone}
                                            onChange={handleChange}
                                            required
                                            style={{
                                                border: '2px solid #e9ecef',
                                                borderRadius: '10px',
                                                padding: '12px'
                                            }}
                                        />
                                    </Form.Group>
                                </div>
                                <div className="col-md-6">
                                    <Form.Group className="mb-4">
                                        <div className="d-flex align-items-center mb-2">
                                            <FaUserShield className="text-primary me-2" />
                                            <Form.Label className="mb-0">Role</Form.Label>
                                        </div>
                                        <Form.Select
                                            name="role"
                                            value={user.role}
                                            onChange={handleChange}
                                            required
                                            style={{
                                                border: '2px solid #e9ecef',
                                                borderRadius: '10px',
                                                padding: '12px'
                                            }}
                                        >
                                            <option value="USER">User</option>
                                            <option value="ADMIN">Admin</option>
                                        </Form.Select>
                                    </Form.Group>
                                </div>
                            </div>

                            <Form.Group className="mb-4">
                                <div className="d-flex align-items-center mb-2">
                                    <FaMapMarkerAlt className="text-primary me-2" />
                                    <Form.Label className="mb-0">Address</Form.Label>
                                </div>
                                <Form.Control
                                    as="textarea"
                                    name="address"
                                    value={user.address}
                                    onChange={handleChange}
                                    required
                                    rows={3}
                                    style={{
                                        border: '2px solid #e9ecef',
                                        borderRadius: '10px',
                                        padding: '12px'
                                    }}
                                />
                            </Form.Group>

                            <div className="d-flex gap-3 justify-content-end mt-4">
                                <Button 
                                    type="button" 
                                    variant="light"
                                    onClick={() => navigate('/member-management')}
                                    disabled={saving}
                                    style={{
                                        padding: '12px 24px',
                                        borderRadius: '10px',
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '8px'
                                    }}
                                >
                                    <FaTimes />
                                    Cancel
                                </Button>
                                <Button 
                                    type="submit" 
                                    disabled={saving}
                                    style={{
                                        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                                        border: 'none',
                                        padding: '12px 24px',
                                        borderRadius: '10px',
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '8px'
                                    }}
                                >
                                    {saving ? (
                                        <>
                                            <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                            Saving Changes...
                                        </>
                                    ) : (
                                        <>
                                            <FaSave />
                                            Save Changes
                                        </>
                                    )}
                                </Button>
                            </div>
                        </Form>
                    )}
                </Card.Body>
            </Card>
        </Container>
    );
};

export default EditUser; 