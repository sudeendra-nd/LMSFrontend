import React, { useState, useEffect } from "react";
import { Container, Row, Col, Card, Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { FaShoppingCart, FaTrash, FaArrowLeft, FaCheck } from 'react-icons/fa';
import axiosInstance from "../axiosInstance";
import { toast } from 'react-toastify';

const Cart = () => {
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [removingItems, setRemovingItems] = useState({});
  const navigate = useNavigate();

  const fetchCartItems = async () => {
    try {
      const response = await axiosInstance.get("/cart/display");
      console.log("Cart items response:", response.data);
      const items = response.data.cartItems || [];
      console.log("Raw cart items:", items);
      const formattedItems = items.map(item => {
        console.log("Processing item:", item);
        console.log("Book data:", item.book);
        return {
          id: item.book?.id || item.bookId,
          title: item.book?.title || '',
          author: item.book?.author || '',
          isbn: item.book?.isbn || '',
          imageUrl: item.book?.imageUrl || item.book?.image_url || ''
        };
      });
      console.log("Formatted items:", formattedItems);
      setCartItems(formattedItems);
    } catch (error) {
      console.error("Error fetching cart:", error);
      toast.error("Failed to load cart items");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCartItems();
  }, []);

  const handleRemoveFromCart = async (bookId) => {
    setRemovingItems(prev => ({ ...prev, [bookId]: true }));
    try {
      console.log("Removing book with ID:", bookId);
      const response = await axiosInstance.delete(`/cart/removeItem/${bookId}`);
      console.log("Remove response:", response.data);
      
      if (response.data.status === "success") {
        toast.success(response.data.message || "Book removed from cart successfully");
        await fetchCartItems();
      } else {
        toast.error(response.data.message || "Failed to remove book");
      }
    } catch (error) {
      console.error("Error removing book:", error.response || error);
      const errorMessage = error.response?.data?.message || "Failed to remove book from cart. Please try again.";
      toast.error(errorMessage);
    } finally {
      setRemovingItems(prev => ({ ...prev, [bookId]: false }));
    }
  };

  const handleCheckout = async () => {
    setIsCheckingOut(true);
    try {
      const response = await axiosInstance.post("/cart/checkout");
      if (response.data.status === "success") {
        toast.success(response.data.message || "Checkout successful! Books have been borrowed.");
        setCartItems([]);
        navigate("/user-dashboard");
      } else {
        toast.error(response.data.message || "Checkout failed");
      }
    } catch (error) {
      console.error("Error during checkout:", error);
      const errorMessage = error.response?.data?.message || "Checkout failed. Please try again.";
      toast.error(errorMessage);
    } finally {
      setIsCheckingOut(false);
    }
  };

  const handleBackToUserDashboard = () => {
    navigate('/user-dashboard');
  };

  return (
    <Container className="py-5">
      <div style={{ 
        background: 'linear-gradient(135deg, #00C9FF 0%, #92FE9D 100%)',
        padding: '20px',
        borderRadius: '10px',
        marginBottom: '20px',
        color: 'white',
        boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
      }}>
        <div className="d-flex align-items-center justify-content-between">
          <h1 className="mb-0">
            <FaShoppingCart className="me-3" />
            Your Cart
          </h1>
          <Button
            variant="outline-light"
            onClick={handleBackToUserDashboard}
            style={{ borderWidth: '2px' }}
          >
            <FaArrowLeft className="me-2" />
            Continue Browsing
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="text-center p-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      ) : cartItems.length === 0 ? (
        <div className="text-center p-5" style={{ background: 'white', borderRadius: '10px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
          <FaShoppingCart style={{ fontSize: '48px', color: '#dee2e6' }} />
          <h3 className="mt-4">Your cart is empty</h3>
          <p className="text-muted mb-4">Add some books to get started!</p>
          <Button
            variant="primary"
            onClick={() => navigate("/user-dashboard")}
            style={{ 
              background: 'linear-gradient(135deg, #6B73FF 0%, #000DFF 100%)',
              border: 'none',
              padding: '10px 30px'
            }}
          >
            <FaArrowLeft className="me-2" />
            Browse Books
          </Button>
        </div>
      ) : (
        <>
        <Row>
            {cartItems.map((item) => (
              <Col key={item.id || item.bookId} md={4} className="mb-4">
                <Card style={{ 
                  width: '100%',
                  height: '600px',
                  borderRadius: '15px',
                  border: 'none',
                  background: 'white',
                  transform: 'translateY(0)',
                  transition: 'all 0.3s ease-in-out',
                  boxShadow: '0 5px 15px rgba(0,0,0,0.08)',
                  overflow: 'hidden',
                  display: 'flex',
                  flexDirection: 'column'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-5px)';
                  e.currentTarget.style.boxShadow = '0 8px 20px rgba(0,0,0,0.12)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = '0 5px 15px rgba(0,0,0,0.08)';
                }}>
                  <div style={{ 
                    position: 'relative', 
                    overflow: 'hidden',
                    height: '300px',
                    width: '100%'
                  }}>
                    <Card.Img
                      variant="top"
                      src={item.imageUrl || item.image_url || 'https://via.placeholder.com/200x300?text=No+Image'}
                      alt={item.title}
                      style={{ 
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                        borderTopLeftRadius: '15px',
                        borderTopRightRadius: '15px'
                      }}
                      onError={(e) => {
                        e.target.src = 'https://via.placeholder.com/200x300?text=No+Image';
                        console.log('Image failed to load:', item.imageUrl);
                      }}
                    />
                  </div>
                  <Card.Body style={{ 
                    padding: '1.5rem',
                    background: 'linear-gradient(to bottom, #ffffff 0%, #f8f9fa 100%)',
                    flex: 1,
                    display: 'flex',
                    flexDirection: 'column'
                  }}>
                    <Card.Title style={{ 
                      fontSize: '1.25rem',
                      fontWeight: '700',
                      marginBottom: '1rem',
                      color: '#2d3436',
                      borderBottom: '2px solid #e9ecef',
                      paddingBottom: '0.5rem',
                      height: '4rem',
                      overflow: 'hidden',
                      display: '-webkit-box',
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: 'vertical'
                    }}>
                      {item.title || 'Untitled Book'}
                    </Card.Title>
                    <Card.Text style={{ 
                      fontSize: '1rem',
                      color: '#636e72',
                      marginBottom: '1rem',
                      flex: 1
                    }}>
                      <div style={{ marginBottom: '0.5rem', height: '1.5rem', overflow: 'hidden' }}>
                        <strong style={{ color: '#2d3436' }}>Author:</strong>{' '}
                        <span style={{ color: '#0984e3' }}>{item.author || 'Unknown'}</span>
                      </div>
                      <div style={{ height: '1.5rem', overflow: 'hidden' }}>
                        <strong style={{ color: '#2d3436' }}>ISBN:</strong>{' '}
                        <span style={{ fontFamily: 'monospace', color: '#6c5ce7' }}>{item.isbn || 'N/A'}</span>
                      </div>
                  </Card.Text>
                    <Button
                      variant="danger"
                      onClick={() => handleRemoveFromCart(item.bookId || item.id)}
                      className="w-100 mt-auto"
                      disabled={removingItems[item.bookId || item.id]}
                      style={{
                        background: 'linear-gradient(135deg, #ff6b6b 0%, #f53e3e 100%)',
                        border: 'none',
                        padding: '12px',
                        borderRadius: '10px',
                        fontWeight: '600',
                        letterSpacing: '0.5px',
                        boxShadow: '0 4px 6px rgba(255, 107, 107, 0.2)',
                        transition: 'all 0.3s ease'
                      }}
                      onMouseEnter={(e) => {
                        if (!removingItems[item.bookId || item.id]) {
                          e.currentTarget.style.transform = 'translateY(-2px)';
                          e.currentTarget.style.boxShadow = '0 6px 8px rgba(255, 107, 107, 0.3)';
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (!removingItems[item.bookId || item.id]) {
                          e.currentTarget.style.transform = 'translateY(0)';
                          e.currentTarget.style.boxShadow = '0 4px 6px rgba(255, 107, 107, 0.2)';
                        }
                      }}
                    >
                      {removingItems[item.bookId || item.id] ? (
                        <>
                          <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                          Removing...
                        </>
                      ) : (
                        <>
                          <FaTrash className="me-2" />
                          Remove from Cart
                        </>
                      )}
                    </Button>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
          <div className="text-center mt-4">
            <Button
              variant="success"
              size="lg"
              onClick={handleCheckout}
              disabled={isCheckingOut}
              style={{ 
                minWidth: '200px',
                background: 'linear-gradient(135deg, #00b894 0%, #00cec9 100%)',
                border: 'none',
                padding: '15px 40px',
                borderRadius: '8px',
                boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
              }}
            >
              {isCheckingOut ? (
                <>
                  <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                  Processing...
                </>
              ) : (
                <>
                  <FaCheck className="me-2" />
                  Checkout
                </>
              )}
        </Button>
      </div>
        </>
      )}
    </Container>
  );
};

export default Cart;
