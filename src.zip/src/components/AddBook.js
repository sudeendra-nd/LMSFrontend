import React, { useState } from 'react';
import { Container, Form, Button, Card } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { FaBook, FaSave, FaTimes, FaUser, FaBarcode, FaImage, FaCubes } from 'react-icons/fa';
import axiosInstance from '../axiosInstance';
import { toast } from 'react-toastify';

const AddBook = () => {
    const navigate = useNavigate();
    const [saving, setSaving] = useState(false);
    const [book, setBook] = useState({
        title: '',
        author: '',
        isbn: '',
        image_url: '',
        copies_available: 1
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setBook(prev => ({
            ...prev,
            [name]: name === 'copies_available' ? parseInt(value) || 0 : value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSaving(true);
        try {
            const response = await axiosInstance.post('/api/books', book);
            if (response.data.status === 'success') {
                toast.success('Book added successfully');
                navigate('/admin');
            } else {
                toast.error(response.data.message || 'Failed to add book');
            }
        } catch (error) {
            console.error('Error adding book:', error);
            toast.error(error.response?.data?.message || 'Failed to add book');
        } finally {
            setSaving(false);
        }
    };

    return (
        <Container className="py-5">
            <Card className="border-0" style={{
                background: 'linear-gradient(145deg, #ffffff 0%, #f5f7fa 100%)',
                borderRadius: '20px',
                boxShadow: '0 10px 20px rgba(0,0,0,0.08)'
            }}>
                <Card.Header style={{
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                    borderRadius: '20px 20px 0 0',
                    padding: '25px'
                }}>
                    <div className="d-flex align-items-center">
                        <div className="bg-white p-2 rounded-circle me-3">
                            <FaBook className="text-primary" size={24} />
                        </div>
                        <div>
                            <h4 className="mb-0 text-white">Add New Book</h4>
                            <p className="mb-0 text-white-50">Add a new book to the library</p>
                        </div>
                    </div>
                </Card.Header>
                <Card.Body className="p-4">
                    <Form onSubmit={handleSubmit}>
                        <div className="row">
                            <div className="col-md-6">
                                <Form.Group className="mb-4">
                                    <div className="d-flex align-items-center mb-2">
                                        <FaBook className="text-primary me-2" />
                                        <Form.Label className="mb-0">Title</Form.Label>
                                    </div>
                                    <Form.Control
                                        type="text"
                                        name="title"
                                        value={book.title}
                                        onChange={handleChange}
                                        required
                                        placeholder="Enter book title"
                                        style={{
                                            border: '2px solid #e9ecef',
                                            borderRadius: '10px',
                                            padding: '12px'
                                        }}
                                    />
                                </Form.Group>
                            </div>
                            <div className="col-md-6">
                                <Form.Group className="mb-4">
                                    <div className="d-flex align-items-center mb-2">
                                        <FaUser className="text-primary me-2" />
                                        <Form.Label className="mb-0">Author</Form.Label>
                                    </div>
                                    <Form.Control
                                        type="text"
                                        name="author"
                                        value={book.author}
                                        onChange={handleChange}
                                        required
                                        placeholder="Enter author name"
                                        style={{
                                            border: '2px solid #e9ecef',
                                            borderRadius: '10px',
                                            padding: '12px'
                                        }}
                                    />
                                </Form.Group>
                            </div>
                        </div>

                        <div className="row">
                            <div className="col-md-6">
                                <Form.Group className="mb-4">
                                    <div className="d-flex align-items-center mb-2">
                                        <FaBarcode className="text-primary me-2" />
                                        <Form.Label className="mb-0">ISBN</Form.Label>
                                    </div>
                                    <Form.Control
                                        type="text"
                                        name="isbn"
                                        value={book.isbn}
                                        onChange={handleChange}
                                        required
                                        placeholder="Enter ISBN"
                                        style={{
                                            border: '2px solid #e9ecef',
                                            borderRadius: '10px',
                                            padding: '12px'
                                        }}
                                    />
                                </Form.Group>
                            </div>
                            <div className="col-md-6">
                                <Form.Group className="mb-4">
                                    <div className="d-flex align-items-center mb-2">
                                        <FaCubes className="text-primary me-2" />
                                        <Form.Label className="mb-0">Available Copies</Form.Label>
                                    </div>
                                    <Form.Control
                                        type="number"
                                        name="copies_available"
                                        value={book.copies_available}
                                        onChange={handleChange}
                                        required
                                        min="0"
                                        style={{
                                            border: '2px solid #e9ecef',
                                            borderRadius: '10px',
                                            padding: '12px'
                                        }}
                                    />
                                </Form.Group>
                            </div>
                        </div>

                        <Form.Group className="mb-4">
                            <div className="d-flex align-items-center mb-2">
                                <FaImage className="text-primary me-2" />
                                <Form.Label className="mb-0">Image URL</Form.Label>
                            </div>
                            <Form.Control
                                type="url"
                                name="image_url"
                                value={book.image_url}
                                onChange={handleChange}
                                required
                                placeholder="Enter book cover image URL"
                                style={{
                                    border: '2px solid #e9ecef',
                                    borderRadius: '10px',
                                    padding: '12px'
                                }}
                            />
                        </Form.Group>

                        <div className="d-flex gap-3 justify-content-end mt-4">
                            <Button 
                                type="button" 
                                variant="light"
                                onClick={() => navigate('/admin')}
                                disabled={saving}
                                style={{
                                    padding: '12px 24px',
                                    borderRadius: '10px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px'
                                }}
                            >
                                <FaTimes />
                                Cancel
                            </Button>
                            <Button 
                                type="submit" 
                                disabled={saving}
                                style={{
                                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                                    border: 'none',
                                    padding: '12px 24px',
                                    borderRadius: '10px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px'
                                }}
                            >
                                {saving ? (
                                    <>
                                        <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                        Adding Book...
                                    </>
                                ) : (
                                    <>
                                        <FaSave />
                                        Add Book
                                    </>
                                )}
                            </Button>
                        </div>
                    </Form>
                </Card.Body>
            </Card>
        </Container>
    );
};

export default AddBook;