import React, { useState, useEffect } from 'react';
import { Container, Form, Button, Card, Row, Col } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { FaUser, FaSave, FaTimes, FaEnvelope, FaPhone, FaMapMarkerAlt } from 'react-icons/fa';
import axiosInstance from '../axiosInstance';
import { toast } from 'react-toastify';

const ProfileSettings = () => {
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [user, setUser] = useState({
        username: '',
        email: '',
        phone: '',
        address: '',
        password: ''
    });

    useEffect(() => {
        const fetchUserDetails = async () => {
            try {
                const username = localStorage.getItem('username');
                if (!username) {
                    navigate('/');
                    return;
                }

                const response = await axiosInstance.get('/api/users');
                const users = response.data;
                const currentUser = users.find(u => u.username === username);
                
                if (currentUser) {
                    setUser({
                        ...currentUser,
                        password: '' // Don't show the current password
                    });
                } else {
                    toast.error('User not found');
                    navigate('/user-dashboard');
                }
            } catch (error) {
                console.error('Error fetching user:', error);
                toast.error('Failed to load user details');
                navigate('/user-dashboard');
            } finally {
                setLoading(false);
            }
        };

        fetchUserDetails();
    }, [navigate]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUser(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(user.email.trim())) {
            toast.error('Please enter a valid email address');
            return;
        }

        // Validate phone number (exactly 10 digits)
        const phoneRegex = /^\d{10}$/;
        if (!phoneRegex.test(user.phone.trim())) {
            toast.error('Phone number must be exactly 10 digits');
            return;
        }

        // Validate address is not empty
        if (!user.address.trim()) {
            toast.error('Address cannot be empty');
            return;
        }

        setSaving(true);
        try {
            // Prepare the update data - only include fields that can be updated
            const updateData = {
                username: user.username,  // Required by backend but won't be changed
                email: user.email.trim(),
                phone: user.phone.trim(),
                address: user.address.trim(),
                role: user.role || 'USER',  // Ensure role is always set
                // Only include password if it's provided and not empty
                ...(user.password?.trim() ? { password: user.password.trim() } : {})
            };
            
            console.log('Sending update data:', updateData); // Debug log
            
            const response = await axiosInstance.put(`/api/users/${user.id}`, updateData);
            console.log('Backend response:', response.data); // Debug log
            
            if (response.data.status === 'success') {
                toast.success('Profile updated successfully');
                navigate('/user-dashboard');
            } else {
                toast.error(response.data.message || 'Failed to update profile');
            }
        } catch (error) {
            console.error('Error updating profile:', error);
            console.error('Error response:', error.response?.data); // Debug log
            
            if (error.response?.data?.message) {
                toast.error(`Update failed: ${error.response.data.message}`);
            } else if (error.response?.status === 400) {
                toast.error('Invalid data provided. Please check your inputs and try again.');
            } else if (error.response?.status === 401) {
                toast.error('Session expired. Please login again.');
                navigate('/');
            } else {
                toast.error('Failed to update profile. Please try again.');
            }
        } finally {
            setSaving(false);
        }
    };

    return (
        <Container className="py-5">
            <Card style={{
                borderRadius: '15px',
                border: 'none',
                boxShadow: '0 4px 20px rgba(0,0,0,0.1)'
            }}>
                <Card.Header style={{
                    background: 'linear-gradient(135deg, #FF6B6B 0%, #A36FFF 100%)',
                    borderRadius: '15px 15px 0 0',
                    padding: '20px',
                    boxShadow: '0 4px 15px rgba(0,0,0,0.1)'
                }}>
                    <div className="d-flex align-items-center">
                        <FaUser className="text-white me-2" size={24} />
                        <h3 className="mb-0 text-white">Profile Settings</h3>
                    </div>
                </Card.Header>

                <Card.Body className="p-4" style={{
                    background: 'linear-gradient(to bottom, #ffffff 0%, #f8f9fa 100%)'
                }}>
                    {loading ? (
                        <div className="text-center p-5">
                            <div className="spinner-border text-primary" role="status">
                                <span className="visually-hidden">Loading...</span>
                            </div>
                            <p className="mt-3 text-muted">Loading your profile...</p>
                        </div>
                    ) : (
                        <Form onSubmit={handleSubmit}>
                            <Row>
                                <Col md={6}>
                                    <Form.Group className="mb-4">
                                        <div className="d-flex align-items-center mb-2">
                                            <FaUser className="text-primary me-2" />
                                            <Form.Label className="mb-0">Username</Form.Label>
                                        </div>
                                        <Form.Control
                                            type="text"
                                            name="username"
                                            value={user.username}
                                            disabled
                                            style={{
                                                background: '#f8f9fa',
                                                border: '2px solid #e9ecef',
                                                borderRadius: '10px',
                                                padding: '12px'
                                            }}
                                        />
                                    </Form.Group>

                                    <Form.Group className="mb-4">
                                        <div className="d-flex align-items-center mb-2">
                                            <FaEnvelope className="text-primary me-2" />
                                            <Form.Label className="mb-0">Email</Form.Label>
                                        </div>
                                        <Form.Control
                                            type="email"
                                            name="email"
                                            value={user.email}
                                            onChange={handleChange}
                                            required
                                            pattern="[^@\s]+@[^@\s]+\.[^@\s]+"
                                            placeholder="Enter your email address"
                                            style={{
                                                border: '2px solid #e9ecef',
                                                borderRadius: '10px',
                                                padding: '12px'
                                            }}
                                        />
                                        <Form.Text className="text-muted">
                                            Enter a valid email address
                                        </Form.Text>
                                    </Form.Group>
                                </Col>

                                <Col md={6}>
                                    <Form.Group className="mb-4">
                                        <div className="d-flex align-items-center mb-2">
                                            <FaPhone className="text-primary me-2" />
                                            <Form.Label className="mb-0">Phone</Form.Label>
                                        </div>
                                        <Form.Control
                                            type="tel"
                                            name="phone"
                                            value={user.phone}
                                            onChange={handleChange}
                                            required
                                            pattern="[0-9]{10}"
                                            placeholder="Enter 10-digit phone number"
                                            style={{
                                                border: '2px solid #e9ecef',
                                                borderRadius: '10px',
                                                padding: '12px'
                                            }}
                                        />
                                        <Form.Text className="text-muted">
                                            Enter a 10-digit phone number
                                        </Form.Text>
                                    </Form.Group>

                                    <Form.Group className="mb-4">
                                        <div className="d-flex align-items-center mb-2">
                                            <FaMapMarkerAlt className="text-primary me-2" />
                                            <Form.Label className="mb-0">Address</Form.Label>
                                        </div>
                                        <Form.Control
                                            as="textarea"
                                            rows={3}
                                            name="address"
                                            value={user.address}
                                            onChange={handleChange}
                                            required
                                            placeholder="Enter your address"
                                            style={{
                                                border: '2px solid #e9ecef',
                                                borderRadius: '10px',
                                                padding: '12px'
                                            }}
                                        />
                                    </Form.Group>
                                </Col>
                            </Row>

                            <Form.Group className="mb-4">
                                <div className="d-flex align-items-center mb-2">
                                    <FaUser className="text-primary me-2" />
                                    <Form.Label className="mb-0">New Password (Optional)</Form.Label>
                                </div>
                                <Form.Control
                                    type="password"
                                    name="password"
                                    value={user.password}
                                    onChange={handleChange}
                                    placeholder="Leave blank to keep current password"
                                    style={{
                                        border: '2px solid #e9ecef',
                                        borderRadius: '10px',
                                        padding: '12px'
                                    }}
                                />
                                <Form.Text className="text-muted">
                                    Only fill this if you want to change your password
                                </Form.Text>
                            </Form.Group>

                            <div className="d-flex gap-3 justify-content-end mt-4">
                                <Button
                                    variant="outline-secondary"
                                    onClick={() => navigate('/user-dashboard')}
                                    style={{ borderRadius: '10px', padding: '12px 24px' }}
                                >
                                    <FaTimes className="me-2" />
                                    Cancel
                                </Button>
                                <Button
                                    type="submit"
                                    variant="primary"
                                    disabled={saving}
                                    style={{
                                        borderRadius: '10px',
                                        padding: '12px 24px',
                                        background: 'linear-gradient(135deg, #FF6B6B 0%, #A36FFF 100%)',
                                        border: 'none',
                                        boxShadow: '0 4px 15px rgba(163,111,255,0.2)',
                                        transition: 'all 0.3s ease'
                                    }}
                                    onMouseEnter={(e) => {
                                        e.currentTarget.style.transform = 'translateY(-2px)';
                                        e.currentTarget.style.boxShadow = '0 6px 20px rgba(163,111,255,0.3)';
                                    }}
                                    onMouseLeave={(e) => {
                                        e.currentTarget.style.transform = 'translateY(0)';
                                        e.currentTarget.style.boxShadow = '0 4px 15px rgba(163,111,255,0.2)';
                                    }}
                                >
                                    {saving ? (
                                        <>
                                            <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                                            Saving...
                                        </>
                                    ) : (
                                        <>
                                            <FaSave className="me-2" />
                                            Save Changes
                                        </>
                                    )}
                                </Button>
                            </div>
                        </Form>
                    )}
                </Card.Body>
            </Card>
        </Container>
    );
};

export default ProfileSettings; 