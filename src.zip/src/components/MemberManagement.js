import React, { useState, useEffect } from 'react';
import { Container, Table, Button, Row, Col, Form, Spinner, Card } from 'react-bootstrap';
import { FaEdit, FaTrash, FaSearch, FaUserCog, FaUser, FaEnvelope, FaPhone } from 'react-icons/fa';
import { Link } from 'react-router-dom';
import axiosInstance from '../axiosInstance';
import { toast } from 'react-toastify';

const MemberManagement = () => {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredUsers, setFilteredUsers] = useState([]);
    const [deletingUsers, setDeletingUsers] = useState({});

    const fetchUsers = async () => {
        try {
            const response = await axiosInstance.get('/api/users');
            setUsers(response.data);
            setFilteredUsers(response.data);
        } catch (error) {
            console.error('Error fetching users:', error);
            toast.error('Failed to load users');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchUsers();
    }, []);

    useEffect(() => {
        const results = users.filter(user =>
            user.username?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            user.phone?.includes(searchTerm)
        );
        setFilteredUsers(results);
    }, [searchTerm, users]);

    const handleDeleteUser = async (id) => {
        setDeletingUsers(prev => ({ ...prev, [id]: true }));
        try {
            const response = await axiosInstance.delete(`/api/users/${id}`);
            if (response.data.status === 'success') {
                setUsers(users.filter(user => user.id !== id));
                toast.success('User deleted successfully');
            } else {
                toast.error(response.data.message || 'Failed to delete user');
            }
        } catch (error) {
            console.error('Error deleting user:', error);
            toast.error('Failed to delete user');
        } finally {
            setDeletingUsers(prev => ({ ...prev, [id]: false }));
        }
    };

    return (
        <Container fluid className="py-5 px-4">
            <Card className="border-0" style={{
                background: 'linear-gradient(145deg, #ffffff 0%, #f5f7fa 100%)',
                borderRadius: '20px',
                boxShadow: '0 10px 20px rgba(0,0,0,0.08)'
            }}>
                <Card.Header style={{
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                    borderRadius: '20px 20px 0 0',
                    padding: '25px'
                }}>
                    <Row className="align-items-center">
                        <Col>
                            <div className="d-flex align-items-center">
                                <div className="bg-white p-2 rounded-circle me-3">
                                    <FaUserCog className="text-primary" size={24} />
                                </div>
                                <div>
                                    <h4 className="mb-0 text-white">Member Management</h4>
                                    <p className="mb-0 text-white-50">Manage library members and their roles</p>
                                </div>
                            </div>
                        </Col>
                        <Col xs="auto">
                            <div className="position-relative" style={{ maxWidth: '300px' }}>
                                <FaSearch className="position-absolute" style={{ left: '15px', top: '12px', color: '#6c757d' }} />
                                <Form.Control
                                    type="text"
                                    placeholder="Search members..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    style={{
                                        background: 'rgba(255, 255, 255, 0.9)',
                                        border: 'none',
                                        borderRadius: '10px',
                                        padding: '12px 12px 12px 40px'
                                    }}
                                />
                            </div>
                        </Col>
                    </Row>
                </Card.Header>
                <Card.Body className="p-4">
                    {loading ? (
                        <div className="text-center p-5">
                            <div className="spinner-border text-primary" role="status">
                                <span className="visually-hidden">Loading...</span>
                            </div>
                            <p className="mt-3 text-muted">Loading members...</p>
                        </div>
                    ) : filteredUsers.length === 0 ? (
                        <div className="text-center p-5">
                            <FaUser style={{ fontSize: '48px', color: '#dee2e6' }} />
                            <h4 className="mt-3">No members found</h4>
                            <p className="text-muted">Try adjusting your search criteria</p>
                        </div>
                    ) : (
                        <div className="table-responsive">
                            <Table hover style={{ marginBottom: 0 }}>
                                <thead>
                                    <tr style={{ background: '#f8f9fa' }}>
                                        <th style={{ padding: '16px', borderTop: 'none' }}>Member</th>
                                        <th style={{ padding: '16px', borderTop: 'none' }}>Contact</th>
                                        <th style={{ padding: '16px', borderTop: 'none' }}>Role</th>
                                        <th style={{ padding: '16px', borderTop: 'none' }}>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {filteredUsers.map(user => (
                                        <tr key={user.id}>
                                            <td style={{ padding: '16px', verticalAlign: 'middle' }}>
                                                <div className="d-flex align-items-center">
                                                    <div className="rounded-circle bg-light p-2 me-3">
                                                        <FaUser className="text-primary" />
                                                    </div>
                                                    <div>
                                                        <h6 className="mb-0">{user.username}</h6>
                                                        <small className="text-muted">{user.address}</small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td style={{ padding: '16px', verticalAlign: 'middle' }}>
                                                <div>
                                                    <div className="d-flex align-items-center mb-1">
                                                        <FaEnvelope className="text-muted me-2" size={12} />
                                                        <small>{user.email}</small>
                                                    </div>
                                                    <div className="d-flex align-items-center">
                                                        <FaPhone className="text-muted me-2" size={12} />
                                                        <small>{user.phone}</small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td style={{ padding: '16px', verticalAlign: 'middle' }}>
                                                <span className={`badge ${user.role === 'ADMIN' ? 'bg-primary' : 'bg-success'}`}
                                                    style={{ padding: '8px 12px', borderRadius: '6px' }}>
                                                    {user.role}
                                                </span>
                                            </td>
                                            <td style={{ padding: '16px', verticalAlign: 'middle' }}>
                                                <div className="d-flex gap-2">
                                                    <Link 
                                                        to={`/edit-user/${user.id}`}
                                                        className="btn btn-sm"
                                                        style={{
                                                            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                                                            border: 'none',
                                                            color: 'white',
                                                            padding: '8px 16px',
                                                            borderRadius: '8px'
                                                        }}
                                                    >
                                                        <FaEdit /> Edit
                                                    </Link>
                                                    <Button
                                                        variant="danger"
                                                        size="sm"
                                                        onClick={() => handleDeleteUser(user.id)}
                                                        disabled={deletingUsers[user.id]}
                                                        style={{
                                                            background: deletingUsers[user.id] ? '#dc3545' : 'linear-gradient(135deg, #ff9a9e 0%, #ff5252 100%)',
                                                            border: 'none',
                                                            padding: '8px 16px',
                                                            borderRadius: '8px'
                                                        }}
                                                    >
                                                        {deletingUsers[user.id] ? (
                                                            <>
                                                                <Spinner
                                                                    as="span"
                                                                    animation="border"
                                                                    size="sm"
                                                                    role="status"
                                                                    aria-hidden="true"
                                                                />
                                                                <span className="ms-1">Deleting...</span>
                                                            </>
                                                        ) : (
                                                            <>
                                                                <FaTrash /> Delete
                                                            </>
                                                        )}
                                                    </Button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </Table>
                        </div>
                    )}
                </Card.Body>
            </Card>
        </Container>
    );
};

export default MemberManagement; 