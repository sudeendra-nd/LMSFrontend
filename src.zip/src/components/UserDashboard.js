import React, { useState, useEffect, useMemo } from "react";
import { Container, Row, Col, Card, Button, Form, Dropdown } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../axiosInstance";
import Layout from "./Layout";
import { FaSearch, FaShoppingCart, FaTimes, FaBook, FaUser, FaCog, FaSignOutAlt } from 'react-icons/fa';
import { toast } from 'react-toastify';

const UserDashboard = () => {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cartItems, setCartItems] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [addingToCart, setAddingToCart] = useState({});
  const [userDetails, setUserDetails] = useState(null);
  const navigate = useNavigate();

  const filteredBooks = useMemo(() => {
    return books.filter(
      (book) =>
        book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        book.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
        book.isbn.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [searchTerm, books]);

  const fetchBooks = async () => {
    try {
      const response = await axiosInstance.get("/api/books");
      setBooks(response.data.content);
    } catch (error) {
      console.error('Error fetching books:', error);
      toast.error('Failed to load books. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const fetchCartItems = async () => {
    try {
      const response = await axiosInstance.get("/cart/display");
      if (response.data.status === "success") {
        setCartItems(response.data.cartItems || []);
      }
    } catch (error) {
      console.error("Error fetching cart items:", error);
    }
  };

  const fetchUserDetails = async () => {
    try {
      const token = localStorage.getItem('token');
      const username = localStorage.getItem('username');
      
      if (!token || !username) {
        navigate('/');
        return;
      }

      const response = await axiosInstance.get("/api/users");
      const users = response.data;
      const currentUser = users.find(user => user.username === username);
      
      if (currentUser) {
        setUserDetails(currentUser);
      } else {
        localStorage.removeItem('token');
        localStorage.removeItem('username');
        localStorage.removeItem('role');
        navigate('/');
      }
    } catch (error) {
      console.error("Error fetching user details:", error);
      if (error.response?.status === 401) {
        localStorage.removeItem('token');
        localStorage.removeItem('username');
        localStorage.removeItem('role');
        navigate('/');
      } else {
        toast.error("Failed to load user details");
      }
    }
  };

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/');
      return;
    }
    
    fetchBooks();
    fetchCartItems();
    fetchUserDetails();
  }, [navigate]);

  const addToCart = async (book) => {
    if (addingToCart[book.id]) return;
    
    setAddingToCart({ ...addingToCart, [book.id]: true });
    try {
      const response = await axiosInstance.post(`/cart/add/${book.id}`);
      if (response.data.status === "success") {
        await fetchCartItems();
        toast.success('Book added to cart successfully!');
      }
    } catch (error) {
      console.error('Error adding book to cart:', error);
      if (error.response?.status === 400) {
        toast.error(error.response.data.message || 'Book already in cart or not available');
      } else {
        toast.error('Failed to add book to cart. Please try again.');
      }
    } finally {
      setAddingToCart({ ...addingToCart, [book.id]: false });
    }
  };

  const goToCart = () => navigate("/cart");

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/');
    toast.success('Logged out successfully');
  };

  return (
    <Layout>
      <Container>
        <div style={{ 
          background: 'linear-gradient(135deg, #6B73FF 0%, #000DFF 100%)',
          padding: '20px',
          borderRadius: '10px',
          marginBottom: '20px',
          color: 'white',
          boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
        }}>
          <div className="d-flex justify-content-between align-items-center">
            <div>
              <h1 className="text-center text-white mb-0">Library Dashboard</h1>
              <p className="text-center mb-0 text-white-50">Discover and borrow amazing books</p>
            </div>
            <Dropdown align="end">
              <Dropdown.Toggle
                variant="transparent"
                id="user-settings-dropdown"
                style={{
                  border: '2px solid rgba(255, 255, 255, 0.2)',
                  borderRadius: '50px',
                  padding: '10px 20px',
                  color: 'white',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  background: 'rgba(255, 255, 255, 0.1)',
                  backdropFilter: 'blur(10px)',
                  transition: 'all 0.3s ease',
                  boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
                }}
              >
                <div style={{
                  width: '35px',
                  height: '35px',
                  borderRadius: '50%',
                  background: 'linear-gradient(135deg, #FF6B6B 0%, #A36FFF 100%)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: '0 2px 5px rgba(163,111,255,0.3)'
                }}>
                  <FaUser size={16} style={{ color: 'white' }} />
                </div>
                <div style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'flex-start',
                  lineHeight: '1.2'
                }}>
                  <span style={{ fontWeight: '600' }}>{userDetails?.username || 'User'}</span>
                  <small style={{ opacity: '0.8', fontSize: '0.8rem' }}>{userDetails?.email || ''}</small>
                </div>
              </Dropdown.Toggle>

              <Dropdown.Menu style={{
                background: 'white',
                borderRadius: '15px',
                padding: '15px',
                boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
                border: 'none',
                minWidth: '250px',
                marginTop: '10px'
              }}>
                <div className="px-3 py-2 text-center border-bottom mb-2">
                  <div style={{
                    width: '60px',
                    height: '60px',
                    borderRadius: '50%',
                    background: 'linear-gradient(135deg, #FF6B6B 0%, #A36FFF 100%)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    margin: '0 auto 10px',
                    boxShadow: '0 2px 10px rgba(163,111,255,0.3)'
                  }}>
                    <FaUser size={24} style={{ color: 'white' }} />
                  </div>
                  <h6 className="mb-1" style={{ fontWeight: '600' }}>{userDetails?.username || 'User'}</h6>
                  <p className="text-muted small mb-0" style={{ fontSize: '0.85rem' }}>{userDetails?.email || 'No email available'}</p>
                </div>
                
                <Dropdown.Item 
                  className="d-flex align-items-center gap-2 py-2"
                  style={{ 
                    borderRadius: '8px',
                    transition: 'all 0.2s ease'
                  }}
                  onClick={() => navigate('/profile-settings')}
                >
                  <div style={{
                    width: '32px',
                    height: '32px',
                    borderRadius: '8px',
                    background: 'rgba(255,107,107,0.1)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                    <FaCog style={{ color: '#FF6B6B' }} />
                  </div>
                  <div>
                    <div style={{ fontWeight: '500' }}>Profile Settings</div>
                    <small className="text-muted">Update your details</small>
                  </div>
                </Dropdown.Item>

                <Dropdown.Divider className="my-2" />
                
                <Dropdown.Item 
                  onClick={handleLogout}
                  className="d-flex align-items-center gap-2 py-2"
                  style={{ 
                    borderRadius: '8px',
                    transition: 'all 0.2s ease'
                  }}
                >
                  <div style={{
                    width: '32px',
                    height: '32px',
                    borderRadius: '8px',
                    background: 'rgba(220,53,69,0.1)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                    <FaSignOutAlt style={{ color: '#dc3545' }} />
                  </div>
                  <div>
                    <div style={{ fontWeight: '500' }}>Logout</div>
                    <small className="text-muted">Sign out of your account</small>
                  </div>
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </div>
        </div>

        <div style={{ 
          background: 'white',
          padding: '20px',
          borderRadius: '10px',
          marginBottom: '20px',
          boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
        }}>
          <Row className="align-items-center">
          <Col md={8}>
              <div className="position-relative">
                <FaSearch className="position-absolute" style={{ left: '15px', top: '12px', color: '#6c757d' }} />
            <Form.Control
              type="text"
              placeholder="Search by title, author, or ISBN"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
                  style={{ 
                    paddingLeft: '40px',
                    borderRadius: '8px',
                    border: '1px solid #e0e0e0',
                    fontSize: '0.95rem'
                  }}
                />
              </div>
          </Col>
          <Col md={2}>
              <Button 
                variant="outline-primary" 
                onClick={() => setSearchTerm("")}
                className="w-100"
                style={{
                  borderRadius: '8px',
                  padding: '8px'
                }}
              >
                <FaTimes className="me-2" />
                Clear
              </Button>
          </Col>
          <Col md={2}>
              <Button 
                variant="success" 
                onClick={goToCart} 
                disabled={cartItems.length === 0}
                className="w-100"
                style={{
                  background: 'linear-gradient(135deg, #00b894 0%, #00cec9 100%)',
                  border: 'none',
                  borderRadius: '8px',
                  padding: '8px'
                }}
              >
                <FaShoppingCart className="me-2" />
                Cart {cartItems.length > 0 && `(${cartItems.length})`}
              </Button>
          </Col>
        </Row>
        </div>

        {loading ? (
          <div className="text-center p-5">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        ) : filteredBooks.length === 0 ? (
          <div className="text-center p-5" style={{ background: 'white', borderRadius: '10px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
            <FaBook style={{ fontSize: '48px', color: '#dee2e6' }} />
            <h4 className="mt-3">No books found</h4>
            <p className="text-muted">Try adjusting your search criteria</p>
          </div>
        ) : (
        <Row>
          {filteredBooks.map((book) => (
            <Col key={book.id} md={4} className="mb-4">
                <Card style={{ 
                  width: '100%',
                  height: '600px',
                  borderRadius: '15px',
                  border: 'none',
                  background: 'white',
                  transform: 'translateY(0)',
                  transition: 'all 0.3s ease-in-out',
                  boxShadow: '0 5px 15px rgba(0,0,0,0.08)',
                  overflow: 'hidden',
                  display: 'flex',
                  flexDirection: 'column'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-5px)';
                  e.currentTarget.style.boxShadow = '0 8px 20px rgba(0,0,0,0.12)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = '0 5px 15px rgba(0,0,0,0.08)';
                }}>
                  <div style={{ 
                    position: 'relative', 
                    overflow: 'hidden',
                    height: '300px',
                    width: '100%'
                  }}>
                <Card.Img
                  variant="top"
                      src={book.image_url || 'https://via.placeholder.com/200x300?text=No+Image'}
                  alt={book.title}
                      style={{ 
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                        borderTopLeftRadius: '15px',
                        borderTopRightRadius: '15px'
                      }}
                      onError={(e) => {
                        e.target.src = 'https://via.placeholder.com/200x300?text=No+Image';
                      }}
                    />
                    <div style={{
                      position: 'absolute',
                      top: '10px',
                      right: '10px',
                      background: book.copies_available > 0 ? 'rgba(72, 187, 120, 0.9)' : 'rgba(229, 62, 62, 0.9)',
                      color: 'white',
                      padding: '5px 10px',
                      borderRadius: '20px',
                      fontSize: '0.85rem',
                      fontWeight: '600',
                      backdropFilter: 'blur(5px)'
                    }}>
                      {book.copies_available > 0 ? `${book.copies_available} Available` : 'Out of Stock'}
                    </div>
                  </div>
                  <Card.Body style={{ 
                    padding: '1.5rem',
                    background: 'linear-gradient(to bottom, #ffffff 0%, #f8f9fa 100%)',
                    flex: 1,
                    display: 'flex',
                    flexDirection: 'column'
                  }}>
                    <Card.Title style={{ 
                      fontSize: '1.25rem',
                      fontWeight: '700',
                      marginBottom: '1rem',
                      color: '#2d3436',
                      borderBottom: '2px solid #e9ecef',
                      paddingBottom: '0.5rem',
                      height: '4rem',
                      overflow: 'hidden',
                      display: '-webkit-box',
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: 'vertical'
                    }}>
                      {book.title}
                    </Card.Title>
                    <Card.Text style={{ 
                      fontSize: '1rem',
                      color: '#636e72',
                      marginBottom: '1rem',
                      flex: 1
                    }}>
                      <div style={{ marginBottom: '0.5rem', height: '1.5rem', overflow: 'hidden' }}>
                        <strong style={{ color: '#2d3436' }}>Author:</strong>{' '}
                        <span style={{ color: '#0984e3' }}>{book.author}</span>
                      </div>
                      <div style={{ height: '1.5rem', overflow: 'hidden' }}>
                        <strong style={{ color: '#2d3436' }}>ISBN:</strong>{' '}
                        <span style={{ fontFamily: 'monospace', color: '#6c5ce7' }}>{book.isbn}</span>
                      </div>
                  </Card.Text>
                    <Button 
                      variant={book.copies_available > 0 ? "primary" : "secondary"}
                      onClick={() => addToCart(book)}
                      className="w-100 mt-auto"
                      disabled={book.copies_available === 0 || addingToCart[book.id]}
                      style={{
                        background: book.copies_available > 0 
                          ? 'linear-gradient(135deg, #6366f1 0%, #4f46e5 100%)' 
                          : 'linear-gradient(135deg, #cbd5e1 0%, #94a3b8 100%)',
                        border: 'none',
                        padding: '12px',
                        borderRadius: '10px',
                        fontWeight: '600',
                        letterSpacing: '0.5px',
                        boxShadow: book.copies_available > 0 
                          ? '0 4px 6px rgba(99, 102, 241, 0.2)' 
                          : 'none',
                        transition: 'all 0.3s ease'
                      }}
                      onMouseEnter={(e) => {
                        if (book.copies_available > 0) {
                          e.currentTarget.style.transform = 'translateY(-2px)';
                          e.currentTarget.style.boxShadow = '0 6px 8px rgba(99, 102, 241, 0.3)';
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (book.copies_available > 0) {
                          e.currentTarget.style.transform = 'translateY(0)';
                          e.currentTarget.style.boxShadow = '0 4px 6px rgba(99, 102, 241, 0.2)';
                        }
                      }}
                    >
                      {addingToCart[book.id] ? (
                        <>
                          <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                          Adding...
                        </>
                      ) : book.copies_available > 0 ? (
                        <>
                          <FaShoppingCart className="me-2" />
                    Add to Cart
                        </>
                      ) : (
                        'Out of Stock'
                      )}
                  </Button>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
        )}
      </Container>
    </Layout>
  );
};

export default UserDashboard;
