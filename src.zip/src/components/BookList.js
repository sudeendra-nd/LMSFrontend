import axios from 'axios';
import { Link } from 'react-router-dom';
import { Button, Container, Table, Form, Row, Col } from 'react-bootstrap';
import { useState, useEffect } from 'react';
import Layout from './Layout';
import axiosInstance from '../axiosInstance';

const BookList = () => {
    const [books, setBooks] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredBooks, setFilteredBooks] = useState([]);

    useEffect(() => {
        axiosInstance.get('/api/books')
            .then(response => {
                const bookData = response.data.content;
                setBooks(bookData);
                setFilteredBooks(bookData);
            })
            .catch(error => console.error('Error fetching books:', error));
    }, []);

    useEffect(() => {
        const results = books.filter(book =>
            book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
            book.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
            book.isbn.toLowerCase().includes(searchTerm.toLowerCase()) ||
            book.copies_available.toString().toLowerCase().includes(searchTerm.toLowerCase()) ||
            book.image_url.toLowerCase().includes(searchTerm.toLowerCase())
        );
        setFilteredBooks(results);
    }, [searchTerm, books]);

    const deleteBook = (id) => {
        axiosInstance.delete(`/api/books/${id}`)
            .then(() => setBooks(books.filter(book => book.id !== id)))
            .catch(error => console.error('Error deleting book:', error));
    };

    return (

        <nav>
            <h1 className="my-4 p-3 text-white bg-primary rounded">
                <span className="px-5">Library Management System</span>
            </h1>
            <Layout>
                <Container>
                    <Row className="mb-3">
                        <Col md={8}>
                            <Form>
                                <Form.Control
                                    type="text"
                                    placeholder="Search by title, author, ISBN, or status"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="shadow-sm"
                                />
                            </Form>
                        </Col>
                        <Col md={2}>
                            <Button type="button" variant="outline-primary" onClick={() => setSearchTerm('')}>Clear</Button>
                        </Col>
                        <Col md={2} className="text-end">
                            <Link to="/add" className="btn btn-primary">Add Book</Link>
                        </Col>
                    </Row>
                    <Table striped bordered hover className="shadow-sm">
                        <thead className="thead-light">
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Author</th>
                                <th>ISBN</th>
                                <th>Copies Available</th>
                                <th>Image URL</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {Array.isArray(filteredBooks) && filteredBooks.map(book => (
                                <tr key={book.id}>
                                    <td>{book.id}</td>
                                    <td>{book.title}</td>
                                    <td>{book.author}</td>
                                    <td>{book.isbn}</td>
                                    <td>{book.copies_available}</td>
                                    <td>{book.image_url}</td>
                                    <td>
                                        <Link to={`http://localhost:8080/api/books/${book.id}`} className="btn btn-warning btn-sm me-2">Edit</Link>
                                        <Button variant="danger" size="sm" onClick={() => deleteBook(book.id)}>Delete</Button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </Container>
            </Layout>
        </nav>

    );
};

export default BookList;
