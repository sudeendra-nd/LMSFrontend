package com.project.library_management_system.entity;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.Date;
@CrossOrigin("http://localhost:3000/")
@Entity
@Table(name="lending")
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class LendingEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "userId", nullable = false)
    private userEntity user;

    @ManyToOne
    @JoinColumn(name = "bookId",referencedColumnName = "id", nullable = false)
    private BookEntity book;

    @Temporal(TemporalType.DATE)
    private Date borrowDate;

    @Temporal(TemporalType.DATE)
    private Date returnDate;

    @Temporal(TemporalType.DATE)
    private Date dueDate;

    @Column
    private boolean collected = false;

    @Column
    private String status = "ACTIVE";
}
